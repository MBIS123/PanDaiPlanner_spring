package com.FYP.PandaiPlanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PandaiPlannerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PandaiPlannerApplication.class, args);
	}

}
