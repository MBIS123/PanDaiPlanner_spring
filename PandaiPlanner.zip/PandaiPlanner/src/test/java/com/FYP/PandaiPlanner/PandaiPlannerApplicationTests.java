package com.FYP.PandaiPlanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PandaiPlannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
